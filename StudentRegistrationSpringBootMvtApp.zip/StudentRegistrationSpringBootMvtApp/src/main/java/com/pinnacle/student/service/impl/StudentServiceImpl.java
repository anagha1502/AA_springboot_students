package com.pinnacle.student.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.pinnacle.student.exception.StudentNotFoundException;
import com.pinnacle.student.model.Student;
import com.pinnacle.student.repository.StudentRepository;
import com.pinnacle.student.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{

    @Autowired
    private StudentRepository repo;

    @Override
    public Student saveStudent(Student student) {
       return repo.save(student);
    }

    @Override
    public List<Student> getAllStudents() {
       return repo.findAll();
    }
    
    


    @Override
    public Student getStudentById(Long id) {
       Optional<Student> stud = repo.findById(id);
       if(stud.isPresent()) {
           return stud.get();
       } else {
           throw new StudentNotFoundException("Student with Id : "+id+" Not Found");
       }
    }

    @Override
    public void deleteStudentById(Long id) {
       repo.delete(getStudentById(id)); 
    }

    @Override
    public void updateStudent(Student student) {
       repo.save(student);
    }
}

