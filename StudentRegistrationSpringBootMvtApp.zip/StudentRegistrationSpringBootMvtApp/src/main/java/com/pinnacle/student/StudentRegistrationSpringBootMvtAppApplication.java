package com.pinnacle.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRegistrationSpringBootMvtAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRegistrationSpringBootMvtAppApplication.class, args);
	}

}
